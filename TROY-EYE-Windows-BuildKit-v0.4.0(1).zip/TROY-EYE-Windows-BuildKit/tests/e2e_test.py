"""
End-to-end protocol test (no display, no Windows needed):
    pip install -r requirements-server.txt websockets pillow psutil mss
    python tests/e2e_test.py
Starts a real server + fake-screen agents and checks consent, control gating, auth, audit, hashing.
"""
import asyncio
import json
import os
import secrets
import socket
import sqlite3
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

import websockets

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "source")
ADMIN = secrets.token_urlsafe(24)
tmp = tempfile.mkdtemp()
DB = os.path.join(tmp, "t.db")
_s = socket.socket()
_s.bind(("127.0.0.1", 0))
PORT = _s.getsockname()[1]
_s.close()
BASE = f"http://127.0.0.1:{PORT}"
WS = f"ws://127.0.0.1:{PORT}"
procs, results = [], []


def check(name, cond):
    results.append(bool(cond))
    print(("PASS " if cond else "FAIL ") + name)


def http(method, path, token=ADMIN, body=None):
    req = urllib.request.Request(
        BASE + path, method=method, data=json.dumps(body).encode() if body is not None else None,
        headers={"Authorization": "Bearer " + token, "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req) as r:
            return r.status, json.loads(r.read() or b"null"), r.headers
    except urllib.error.HTTPError as e:
        return e.code, None, e.headers


def start_agent(token, *flags, name="agent", extra_env=None, args=None):
    path = os.path.join(tmp, name + ".log")
    out = open(path, "w")
    lock_dir = os.path.join(tmp, name)
    os.makedirs(lock_dir, exist_ok=True)
    env = dict(os.environ, LOCALAPPDATA=tmp, TMPDIR=lock_dir, **(extra_env or {}))
    p = subprocess.Popen(
        [sys.executable, os.path.join(SRC, "troyeye_agent.py"), *(args or ["--server", BASE, "--token", token]), "--fake", *flags],
        stdout=out, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, env=env)
    procs.append(p)
    return p, path


async def wait_online(aid, t=15):
    for _ in range(t * 10):
        _, agents, _ = http("GET", "/api/agents")
        if any(a["agent_id"] == aid and a["online"] for a in agents):
            return True
        await asyncio.sleep(0.1)
    return False


async def viewer(aid, control, send_input=False, frames_wanted=2):
    _, t, _ = http("POST", "/api/ticket")
    q = f"{WS}/ws/viewer?ticket={t['ticket']}&agent_id={aid}" + ("&control=1" if control else "")
    got = {"frames": 0, "approved": None, "denied": None}
    async with websockets.connect(q, max_size=None) as ws:
        async def rd():
            async for m in ws:
                if isinstance(m, bytes):
                    got["frames"] += 1
                else:
                    d = json.loads(m)
                    if d["type"] == "approved":
                        got["approved"] = d
                    if d["type"] == "denied":
                        got["denied"] = d
                if got["frames"] >= frames_wanted or got["denied"]:
                    return
        await asyncio.wait_for(rd(), 20)
        if send_input:
            await ws.send(json.dumps({"t": "key", "k": "a", "d": True}))
            await ws.send(json.dumps({"t": "evil", "x": 1}))
            await ws.send(b"\x00binary")
            await asyncio.sleep(0.6)
    return got


async def main():
    env = dict(os.environ, ADMIN_TOKEN=ADMIN, PORT=str(PORT), SERVER_IP="127.0.0.1", TROYEYE_DB=DB, APPROVAL_TIMEOUT="8")
    srv = subprocess.Popen([sys.executable, os.path.join(SRC, "main.py")], env=env,
                           stdout=open(os.path.join(tmp, "srv.log"), "w"), stderr=subprocess.STDOUT)
    procs.append(srv)
    for _ in range(100):
        try:
            urllib.request.urlopen(BASE + "/healthz")
            break
        except Exception:
            time.sleep(0.1)

    r = subprocess.run([sys.executable, os.path.join(SRC, "main.py")],
                       env=dict(os.environ, ADMIN_TOKEN="changeme", TROYEYE_DB=os.path.join(tmp, "x.db")),
                       capture_output=True, text=True)
    check("server refuses default/weak ADMIN_TOKEN", r.returncode != 0 and "ADMIN_TOKEN" in (r.stdout + r.stderr))
    check("bad admin token -> 401", http("GET", "/api/agents", "nope")[0] == 401)
    st, _, hdr = http("GET", "/api/agents")
    check("admin token works + security headers", st == 200 and "Content-Security-Policy" in hdr and hdr["X-Frame-Options"] == "DENY")

    _, e1, _ = http("POST", "/api/enroll", body={"hostname": "PC-ONE"})
    _, e2, _ = http("POST", "/api/enroll", body={"hostname": "PC-TWO"})
    stored = [row[0] for row in sqlite3.connect(DB).execute("SELECT token FROM agents")]
    check("device tokens stored hashed, not raw", e1["token"] not in stored and all(len(x) == 64 for x in stored))
    check("enroll validation (empty hostname -> 422)", http("POST", "/api/enroll", body={"hostname": ""})[0] == 422)

    try:
        async with websockets.connect(f"{WS}/ws/agent", additional_headers={"Authorization": "Bearer wrong"}) as w:
            await w.recv()
        check("bad device token rejected", False)
    except Exception:
        check("bad device token rejected", True)

    p1, log1 = start_agent(e1["token"], "--auto-approve", name="a1")
    check("agent comes online (token sent in header)", await wait_online(e1["agent_id"]))
    g = await viewer(e1["agent_id"], control=True, send_input=True)
    check("approved session streams frames", g["frames"] >= 2 and g["approved"] and g["approved"]["control"] is True)
    time.sleep(0.3)
    txt = open(log1).read()
    check("input forwarded when control granted, only whitelisted events", "'k': 'a'" in txt and "evil" not in txt)

    open(log1, "w").close()
    g = await viewer(e1["agent_id"], control=False, send_input=True)
    time.sleep(0.3)
    check("view-only session: frames yes, input dropped",
          g["frames"] >= 2 and g["approved"]["control"] is False and "[fake input]" not in open(log1).read())

    p2, _ = start_agent(e2["token"], name="a2")
    check("second agent online", await wait_online(e2["agent_id"]))
    g = await viewer(e2["agent_id"], control=True)
    check("no prompt possible -> request DENIED, zero frames", g["denied"] is not None and g["frames"] == 0)

    _, t, _ = http("POST", "/api/ticket")
    q = f"{WS}/ws/viewer?ticket={t['ticket']}&agent_id={e1['agent_id']}"
    async with websockets.connect(q) as w:
        await w.recv()
    try:
        async with websockets.connect(q) as w:
            await w.recv()
        check("ticket cannot be reused", False)
    except Exception:
        check("ticket cannot be reused", True)

    start_agent(e1["token"], "--auto-approve", name="a1b")
    time.sleep(2)
    _, agents, _ = http("GET", "/api/agents")
    check("duplicate agent instance keeps device online",
          any(a["agent_id"] == e1["agent_id"] and a["online"] for a in agents))

    _, audit, _ = http("GET", "/api/audit")
    events = [a["event"] for a in audit]
    check("audit has requested/allowed/denied/ended", all(x in events for x in ("requested", "allowed", "denied", "ended")))

    # --- USB + folder auditing: off by default, enabled by editing config, hot-reloaded
    _, e3, _ = http("POST", "/api/enroll", body={"hostname": "PC-THREE"})
    cfg_path, usb_file = os.path.join(tmp, "agent3.json"), os.path.join(tmp, "usb.txt")
    watch = os.path.join(tmp, "watched"); os.makedirs(watch)
    open(usb_file, "w").close()
    json.dump({"server": BASE, "token": e3["token"]}, open(cfg_path, "w"))
    p3, log3 = start_agent(None, name="a3", args=["--config", cfg_path], extra_env={"TROYEYE_FAKE_USB": usb_file})
    check("agent runs from agent.json", await wait_online(e3["agent_id"]))
    open(usb_file, "w").write("E: BACKUP\n"); open(os.path.join(watch, "before.txt"), "w").write("x")
    time.sleep(5)
    _, audit, _ = http("GET", "/api/audit?limit=100")
    check("monitoring is OFF by default (no events reported)", not any(a["event"].startswith(("usb", "file")) for a in audit))
    json.dump({"server": BASE, "token": e3["token"], "usb_audit": True, "watch_folders": [watch], "watch_interval": 2}, open(cfg_path, "w"))
    time.sleep(6)  # reload + baseline
    open(usb_file, "w").write("E: BACKUP\nF: CAMERA\n"); open(os.path.join(watch, "new.txt"), "w").write("secret contents")
    time.sleep(6)
    _, audit, _ = http("GET", "/api/audit?limit=100")
    got = {(a["event"], a["detail"]) for a in audit}
    check("config change hot-reloads; USB insert reported", ("usb inserted", "F: CAMERA") in got)
    check("folder change reported (name only, no contents)", ("file created", os.path.join(watch, "new.txt")) in got and not any("secret" in a["detail"] for a in audit))
    check("agent logged the same events locally", "audit: usb inserted F: CAMERA" in open(log3).read())

    check("remove device", http("DELETE", f"/api/agents/{e2['agent_id']}")[0] == 200)
    for _ in range(50):
        if p2.poll() is not None:
            break
        time.sleep(0.1)
    check("removed agent exits and does not retry", p2.poll() == 2)

    print(f"\n{sum(results)}/{len(results)} passed")
    return all(results)


try:
    ok = asyncio.run(main())
finally:
    for p in procs:
        try:
            p.kill()
        except Exception:
            pass
sys.exit(0 if ok else 1)
