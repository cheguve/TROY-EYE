@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo TROY EYE - Windows x64 build 0.4.0
where py >nul 2>nul
if errorlevel 1 goto nopy
py -3.11 -c "import struct,sys;sys.exit(0 if struct.calcsize('P')*8==64 else 1)" >nul 2>nul
if errorlevel 1 goto nopy
if not exist .build-venv py -3.11 -m venv .build-venv
if errorlevel 1 goto fail
call .build-venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements-build.txt
if errorlevel 1 goto fail
if exist dist rmdir /s /q dist
if exist build rmdir /s /q build
pyinstaller --noconfirm --clean --onedir --windowed --name TROY-EYE-Agent --collect-all mss --collect-all pyautogui --collect-all websockets --hidden-import pymsgbox --hidden-import pytweening --hidden-import pyscreeze source\troyeye_agent.py
if errorlevel 1 goto fail
if exist installer\TROY-EYE-Agent rmdir /s /q installer\TROY-EYE-Agent
xcopy /E /I /Y /Q dist\TROY-EYE-Agent installer\TROY-EYE-Agent >nul
if errorlevel 1 goto fail
echo.
echo Agent built: installer\TROY-EYE-Agent\TROY-EYE-Agent.exe
certutil -hashfile installer\TROY-EYE-Agent\TROY-EYE-Agent.exe SHA256
set "ISCC="
for %%P in ("%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" "%ProgramFiles%\Inno Setup 6\ISCC.exe" "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe") do if exist %%P set "ISCC=%%~P"
if not defined ISCC goto noinno
"%ISCC%" installer\TROY-EYE.iss
if errorlevel 1 goto fail
echo.
echo Installer built: installer\Output\TROY-EYE-Setup-x64.exe
pause
exit /b 0
:noinno
echo.
echo Inno Setup 6.3+ not found. Install it, then open installer\TROY-EYE.iss and press Compile.
pause
exit /b 0
:nopy
echo Python 3.11 x64 is needed ONLY on this build computer, not on the installed laptops.
echo Install it from python.org and retry.
pause
exit /b 1
:fail
echo Build failed. See the error above.
pause
exit /b 1
