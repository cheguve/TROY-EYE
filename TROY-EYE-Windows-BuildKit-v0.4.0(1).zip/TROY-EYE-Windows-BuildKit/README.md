# TROY EYE 0.4.0 - Windows x64 build kit

Consent-based remote support. The agent on the Windows laptop connects OUT to your server.
Nothing is captured or controllable until the PC owner clicks Allow.

## Contents
| Path | Purpose |
|---|---|
| `source/main.py` | Server: relay, dashboard API, audit log (SQLite) |
| `source/viewer.html` | Admin dashboard + remote viewer (served by the server) |
| `source/troyeye_agent.py` | Windows agent |
| `build-windows.bat` | Builds the agent (PyInstaller one-folder) and, if Inno Setup is found, the installer |
| `installer/TROY-EYE.iss`, `installer/NOTICE.txt` | GUI installer + consent notice |
| `tests/e2e_test.py` | Protocol test, runs on any OS |
| `requirements-server.txt`, `requirements-build.txt` | Dependencies |

## 1. Run the server
```
pip install -r requirements-server.txt
set ADMIN_TOKEN=<random 16+ characters>      (Linux: export ADMIN_TOKEN=...)
python main.py
```
Put it behind HTTPS. The server refuses to start with a missing/short/`changeme` admin token.
Open the site, sign in with the admin token, "Add a device", copy the URL + token shown once.

## 2. Build (Windows 11 x64 build PC)
1. Install Python 3.11 x64 and Inno Setup 6.3+ (build PC only).
2. Run `build-windows.bat`.
3. Output: `installer\Output\TROY-EYE-Setup-x64.exe` (agent folder: `installer\TROY-EYE-Agent\`).

## 3. Install on a laptop
Run the setup, accept the notice, enter the website URL and device token (one token per laptop).
Silent: `TROY-EYE-Setup-x64.exe /VERYSILENT /SERVER=https://... /TOKEN=...`
Upgrade: run the new setup, leave URL/token blank to keep the existing config.
Settings: Start Menu > **TROY EYE Settings** (URL, token, USB report, watched folders; asks for administrator approval; the running agent reloads by itself).
Config file: `C:\Program Files\TROY EYE\agent.json` (optional keys `fps`, `max_width`, `quality`, `watch_interval`).
Log: `%LOCALAPPDATA%\TROY EYE\agent.log`.

## Windows test checklist (not testable on Linux)
1. Build succeeds; setup installs; "TROY EYE" appears in Task Manager > Startup apps and Installed apps.
2. Agent shows Online in the dashboard. Reboot, log in: Online again, one process only.
3. Connect: Allow prompt appears on the laptop. Deny -> refused. Allow view only -> no control. Allow view + control -> mouse, keyboard, scroll work.
4. Banner visible; "Stop sharing" ends the session. No key/mouse left stuck afterwards.
5. Remove the device in the dashboard: agent exits. Uninstall: process, startup entry, agent.json gone.
6. Settings: change URL/token/USB/folder; UAC prompt appears; agent reloads; insert a USB stick and change a file in a watched folder; events appear in Session history and agent.log.
7. Repeat on Windows 10 x64, and with display scaling 125%/150%.

## Known limits
- Controls only the primary monitor. The UAC secure desktop and lock screen cannot be captured or controlled (agent runs as the user, not as a service).
- `agent.json` is readable by local users (it must be, the agent runs as the user).
- PyInstaller + remote-control + startup entry can trigger antivirus warnings. Code-sign the exe and installer before wider rollout.
- USB report covers removable-class drives (flash drives, card readers); external USB hard disks that Windows reports as fixed disks are not detected. Folder report: names + change type only, polled every 10 s, up to 5,000 files, 3 levels deep, per PC; both OFF by default and switchable only on the PC, not from the server.
- Test on machines you own or are authorised to administer.
