; TROY EYE visible GUI installer (Inno Setup 6.3 or newer).
; Needs the folder TROY-EYE-Agent\ (PyInstaller --onedir output) beside this script;
; build-windows.bat creates it.
#define MyAppName "TROY EYE"
#define MyAppVersion "0.4.0"
#define MyAppExe "TROY-EYE-Agent.exe"

[Setup]
AppId={{C9A2D5B4-DA4A-4E52-9F2A-8D6BCE82B6C1}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher=TROY EYE
DefaultDirName={autopf}\TROY EYE
DefaultGroupName=TROY EYE
DisableProgramGroupPage=yes
OutputDir=Output
OutputBaseFilename=TROY-EYE-Setup-x64
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
PrivilegesRequired=admin
WizardStyle=modern
Compression=lzma2
SolidCompression=yes
LicenseFile=NOTICE.txt
Uninstallable=yes
UninstallDisplayName={#MyAppName}
UninstallDisplayIcon={app}\{#MyAppExe}

[Files]
Source: "TROY-EYE-Agent\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\TROY EYE"; Filename: "{app}\{#MyAppExe}"; Parameters: "--config ""{app}\agent.json"""
Name: "{group}\TROY EYE Settings"; Filename: "{app}\{#MyAppExe}"; Parameters: "--settings --config ""{app}\agent.json"""
Name: "{group}\Uninstall TROY EYE"; Filename: "{uninstallexe}"

[Registry]
; Visible Startup entry for every user (Task Manager > Startup apps). Removed on uninstall.
Root: HKLM; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; ValueName: "TROY EYE"; ValueData: """{app}\{#MyAppExe}"" --config ""{app}\agent.json"""; Flags: uninsdeletevalue

[Run]
; runasoriginaluser: start it as the person using the PC, not as the elevated installer account.
Filename: "{app}\{#MyAppExe}"; Parameters: "--config ""{app}\agent.json"""; Description: "Launch TROY EYE"; Flags: postinstall nowait runasoriginaluser skipifsilent

[UninstallRun]
Filename: "{sys}\taskkill.exe"; Parameters: "/F /IM {#MyAppExe}"; Flags: runhidden; RunOnceId: "StopTroyEye"

[UninstallDelete]
Type: files; Name: "{app}\agent.json"
Type: dirifempty; Name: "{app}"

[Code]
var
  ServerPage, TokenPage: TInputQueryWizardPage;
  ParamServer, ParamToken: String;

function IsSafeChar(C: Char): Boolean;
begin
  Result := ((C >= 'a') and (C <= 'z')) or ((C >= 'A') and (C <= 'Z')) or
            ((C >= '0') and (C <= '9')) or (C = '-') or (C = '_');
end;

function ValidToken(const T: String): Boolean;
var I: Integer;
begin
  Result := Length(T) >= 20;
  for I := 1 to Length(T) do
    if not IsSafeChar(T[I]) then Result := False;
end;

function ValidUrl(const U: String): Boolean;
var L: String;
begin
  L := Lowercase(U);
  Result := (Pos(' ', U) = 0) and (Pos('"', U) = 0) and (Pos('\', U) = 0) and
            ((Copy(L, 1, 8) = 'https://') and (Length(L) > 8) or
             (Copy(L, 1, 16) = 'http://localhost') or (Copy(L, 1, 16) = 'http://127.0.0.1'));
end;

function HasExistingConfig(): Boolean;
begin
  Result := FileExists(AddBackslash(WizardDirValue) + 'agent.json');
end;

procedure InitializeWizard;
begin
  ParamServer := Trim(ExpandConstant('{param:SERVER|}'));
  ParamToken := Trim(ExpandConstant('{param:TOKEN|}'));
  ServerPage := CreateInputQueryPage(wpSelectDir, 'Website connection',
    'Enter your TROY EYE website address',
    'Use the HTTPS address provided by your server administrator. When upgrading, leave blank to keep the current setting.');
  ServerPage.Add('Website URL (https://...)', False);
  ServerPage.Values[0] := ParamServer;
  TokenPage := CreateInputQueryPage(ServerPage.ID, 'Device enrollment',
    'Enter this laptop''s enrollment token',
    'Use a separate enrollment token for each laptop. When upgrading, leave blank to keep the current setting.');
  TokenPage.Add('Device token', True);
  TokenPage.Values[0] := ParamToken;
end;

function ShouldSkipPage(PageID: Integer): Boolean;
begin
  Result := False;
  if (PageID = ServerPage.ID) and (ParamServer <> '') then Result := True;
  if (PageID = TokenPage.ID) and (ParamToken <> '') then Result := True;
end;

function NextButtonClick(CurPageID: Integer): Boolean;
begin
  Result := True;
  if CurPageID = ServerPage.ID then
  begin
    ServerPage.Values[0] := Trim(ServerPage.Values[0]);
    if not ((ServerPage.Values[0] = '') and HasExistingConfig()) and not ValidUrl(ServerPage.Values[0]) then
    begin
      MsgBox('Enter a valid HTTPS address, for example https://eye.example.com', mbError, MB_OK);
      Result := False;
    end;
  end
  else if CurPageID = TokenPage.ID then
  begin
    TokenPage.Values[0] := Trim(TokenPage.Values[0]);
    if not ((TokenPage.Values[0] = '') and HasExistingConfig()) and not ValidToken(TokenPage.Values[0]) then
    begin
      MsgBox('The device token looks wrong. Paste it exactly as shown in the dashboard (letters, digits, - and _ only).', mbError, MB_OK);
      Result := False;
    end;
  end;
end;

function PrepareToInstall(var NeedsRestart: Boolean): String;
var RC: Integer;
begin
  Result := '';
  if not ((ServerPage.Values[0] = '') and (TokenPage.Values[0] = '') and HasExistingConfig()) then
  begin
    if not ValidUrl(ServerPage.Values[0]) then Result := 'The website URL is missing or invalid (it must start with https://).'
    else if not ValidToken(TokenPage.Values[0]) then Result := 'The device token is missing or invalid.';
  end;
  if Result = '' then
  begin
    { stop a running agent so its files can be replaced (upgrade) }
    Exec(ExpandConstant('{sys}\taskkill.exe'), '/F /IM {#MyAppExe}', '', SW_HIDE, ewWaitUntilTerminated, RC);
    Sleep(800);
  end;
end;

procedure CurStepChanged(CurStep: TSetupStep);
var Cfg: String;
begin
  if CurStep = ssPostInstall then
  begin
    if (ServerPage.Values[0] <> '') and (TokenPage.Values[0] <> '') then
    begin
      Cfg := '{"server":"' + ServerPage.Values[0] + '","token":"' + TokenPage.Values[0] + '"}';
      SaveStringToFile(ExpandConstant('{app}\agent.json'), Cfg, False);
    end;
  end;
end;
