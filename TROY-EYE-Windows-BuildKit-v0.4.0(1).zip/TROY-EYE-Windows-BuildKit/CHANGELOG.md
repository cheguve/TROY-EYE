# 0.4.0
- TROY EYE Settings window (Start Menu): server URL, token, USB report, watched folders. Elevates via UAC only when saving; agent hot-reloads agent.json.
- USB insert/remove report (removable drives; drive letter + label) and folder change report (names + change type). Both OFF by default, enabled only on the PC, disclosed in the installer notice, mirrored to agent.log. Server stores them in the session history (capped, flood-limited, whitelisted).
- Metadata only: no file contents, ever.

# 0.3.0
Consent
- Owner chooses view only or view + control; control is gated in agent AND server.
- Banner states whether control is active; session log on the PC; server-side session history.
- Prompt fails closed (denied) if it cannot be shown. `--auto-approve`/`--fake` disabled in release builds.
- Hard session cap (default 1 h), re-approval required.
Security
- Device tokens hashed in DB (v0.2 DBs migrate automatically); token sent in header, not URL.
- One-time 30 s tickets for dashboard/viewer sockets; admin token no longer in WS URLs.
- Refuses weak ADMIN_TOKEN; constant-time compare; failed-auth rate limit; CORS removed.
- CSP (script hash), nosniff, no-store, frame deny. Telemetry whitelist; viewer input whitelist.
- Agent refuses plain http to non-local servers.
Reliability
- Fixed: duplicate agent connection marked device offline; reconnect backoff never reset.
- Fixed: scroll was ~1/120 of a notch on Windows; stuck keys/buttons after session end.
- Capture errors handled (UAC/display change); single-instance guard; logging works in windowed exe.
- Dashboard patches live data instead of polling.
Installer
- Startup entry now HKLM Run via [Registry] (removed on uninstall); launch runs as the original user.
- One-folder build (fewer AV false positives, faster start); URL/token validation; silent params; upgrade keeps config; agent stopped on upgrade/uninstall; consent notice page.
