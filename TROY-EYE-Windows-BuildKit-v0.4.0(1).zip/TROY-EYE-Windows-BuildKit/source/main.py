"""
TROY EYE server  (v0.4.0)
-------------------------
Relay + dashboard for consent-based remote support. Single file, SQLite, no other services.

Persists (SQLite):
    agents  - enrolled device identity + SHA-256 of its token (raw token is never stored)
    audit   - who asked for a session, whether the PC owner allowed it, when it ended
              (metadata only: never screen content, never keystrokes)

RAM only (lost on restart): CPU/RAM/disk snapshots, live sessions, one-time sign-in tickets.

Run:
    pip install -r requirements-server.txt
    ADMIN_TOKEN=<random 16+ chars> python3 -u main.py
Put it behind HTTPS (reverse proxy / host TLS). Plain http is for localhost testing only.

Environment:
    ADMIN_TOKEN              required, >= 16 chars, not "changeme"
    PORT / SERVER_PORT       listen port (default 8000)
    SERVER_IP                bind address (default 0.0.0.0)
    TROYEYE_DB               SQLite path (default agents.db)
    APPROVAL_TIMEOUT         seconds the PC owner has to click Allow (default 60)
    MAX_SESSION_SECONDS      hard cap on one session (default 3600); the viewer must be re-approved
    TROYEYE_TRUST_PROXY=1    use X-Forwarded-For for rate limiting (only behind your own proxy)
    TROYEYE_ALLOW_WEAK_ADMIN=1   dev only: allow a short/default admin token
"""

import asyncio
import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import sqlite3
import sys
import time
from collections import defaultdict, deque
from contextlib import closing
from typing import Dict

from fastapi import FastAPI, Header, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

VERSION = "0.4.0"
HERE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("TROYEYE_DB") or os.environ.get("CHEPRABHA_DB") or "agents.db"
ADMIN_TOKEN = os.environ.get("ADMIN_TOKEN", "")
PORT = int(os.environ.get("PORT", os.environ.get("SERVER_PORT", 8000)))
HOST = os.environ.get("SERVER_IP", "0.0.0.0")
APPROVAL_TIMEOUT = int(os.environ.get("APPROVAL_TIMEOUT", 60))
MAX_SESSION_SECONDS = int(os.environ.get("MAX_SESSION_SECONDS", 3600))
TRUST_PROXY = os.environ.get("TROYEYE_TRUST_PROXY") == "1"

if (len(ADMIN_TOKEN) < 16 or ADMIN_TOKEN == "changeme") and os.environ.get("TROYEYE_ALLOW_WEAK_ADMIN") != "1":
    sys.exit("Refusing to start: set ADMIN_TOKEN to a random value of at least 16 characters "
             "(e.g. python3 -c \"import secrets;print(secrets.token_urlsafe(24))\").")

app = FastAPI(title="TROY EYE", docs_url=None, redoc_url=None, openapi_url=None)

# ------------------------------------------------------------ security headers --

def _script_hash() -> str:
    try:
        with open(os.path.join(HERE, "viewer.html"), encoding="utf-8") as f:
            m = re.search(r"<script>(.*?)</script>", f.read(), re.S)
        digest = base64.b64encode(hashlib.sha256(m.group(1).encode("utf-8")).digest()).decode()
        return f"'sha256-{digest}'"
    except Exception:
        return "'none'"


CSP = ("default-src 'none'; script-src " + _script_hash() + "; style-src 'unsafe-inline'; "
       "connect-src 'self' ws: wss:; img-src 'self' data: blob:; base-uri 'none'; "
       "form-action 'none'; frame-ancestors 'none'")


@app.middleware("http")
async def security_headers(request: Request, call_next):
    resp = await call_next(request)
    resp.headers["Content-Security-Policy"] = CSP
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Referrer-Policy"] = "no-referrer"
    resp.headers["Cache-Control"] = "no-store"
    return resp


@app.get("/", include_in_schema=False)
def viewer_page():
    return FileResponse(os.path.join(HERE, "viewer.html"), media_type="text/html")


@app.get("/healthz", include_in_schema=False)
def healthz():
    return {"ok": True, "version": VERSION}

# ---------------------------------------------------------------- helpers/auth --

def _eq(a: str, b: str) -> bool:
    return hmac.compare_digest(a.encode("utf-8"), b.encode("utf-8"))


def _hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _bearer(authorization: str | None) -> str:
    if authorization and authorization.startswith("Bearer "):
        return authorization[7:].strip()
    return ""


def _client_ip(conn) -> str:
    if TRUST_PROXY:
        fwd = conn.headers.get("x-forwarded-for")
        if fwd:
            return fwd.split(",")[0].strip()
    return conn.client.host if conn.client else "?"


FAIL_WINDOW, FAIL_MAX = 300, 10
_fails: Dict[str, deque] = defaultdict(deque)


def _blocked(ip: str) -> bool:
    q = _fails[ip]
    now = time.time()
    while q and now - q[0] > FAIL_WINDOW:
        q.popleft()
    if not q:
        _fails.pop(ip, None)
    return len(q) >= FAIL_MAX


def _record_fail(ip: str):
    _fails[ip].append(time.time())


def require_admin(request: Request, authorization: str | None):
    ip = _client_ip(request)
    if _blocked(ip):
        raise HTTPException(status_code=429, detail="too many failed attempts, try again later")
    if not _eq(_bearer(authorization), ADMIN_TOKEN):
        _record_fail(ip)
        raise HTTPException(status_code=401, detail="bad admin token")


# One-time, 30-second tickets so the admin token never appears in a WebSocket URL / proxy log.
tickets: Dict[str, float] = {}


def _use_ticket(ticket: str) -> bool:
    now = time.time()
    for t in [t for t, exp in tickets.items() if exp < now]:
        tickets.pop(t, None)
    return tickets.pop(ticket, 0) > now

# --------------------------------------------------------------------- storage --

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA secure_delete = ON")
    return conn


def init_db():
    with closing(db()) as conn:
        conn.execute(
            """CREATE TABLE IF NOT EXISTS agents (
                id TEXT PRIMARY KEY,
                hostname TEXT NOT NULL,
                client TEXT NOT NULL DEFAULT 'Default',
                site TEXT NOT NULL DEFAULT 'Main',
                token TEXT NOT NULL UNIQUE,   -- SHA-256 hex of the device token
                created_at REAL NOT NULL)"""
        )
        conn.execute(
            """CREATE TABLE IF NOT EXISTS audit (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts REAL NOT NULL,
                agent_id TEXT NOT NULL,
                hostname TEXT NOT NULL,
                event TEXT NOT NULL,
                detail TEXT NOT NULL DEFAULT '')"""
        )
        # migrate v0.2 rows that stored the raw token
        for r in conn.execute("SELECT id, token FROM agents").fetchall():
            if not re.fullmatch(r"[0-9a-f]{64}", r["token"]):
                conn.execute("UPDATE agents SET token = ? WHERE id = ?", (_hash_token(r["token"]), r["id"]))
        conn.commit()


init_db()


def _audit(agent_id: str, event: str, detail: str = ""):
    try:
        with closing(db()) as conn:
            row = conn.execute("SELECT hostname FROM agents WHERE id = ?", (agent_id,)).fetchone()
            conn.execute(
                "INSERT INTO audit (ts, agent_id, hostname, event, detail) VALUES (?,?,?,?,?)",
                (time.time(), agent_id, row["hostname"] if row else "?", event, detail[:200]),
            )
            conn.execute("DELETE FROM audit WHERE id <= (SELECT MAX(id) FROM audit) - 50000")  # cap history
            conn.commit()
    except Exception as e:
        print("[audit] write failed:", e, flush=True)


live_state: Dict[str, dict] = {}
agent_sockets: Dict[str, WebSocket] = {}
dashboard_sockets: list[WebSocket] = []
sessions: Dict[str, dict] = {}

TELE_KEYS = {"os", "host", "cpu", "ram", "disk", "uptime_s"}
INPUT_TYPES = {"move", "down", "up", "scroll", "key"}
AGENT_EVENTS = {"usb inserted", "usb removed", "file created", "file modified", "file deleted", "file activity"}
_event_times: Dict[str, deque] = defaultdict(deque)  # per-agent flood limit: 200 events / minute

# ------------------------------------------------------------------ admin API --

class EnrollRequest(BaseModel):
    hostname: str = Field(min_length=1, max_length=64)
    client: str = Field(default="Default", max_length=64)
    site: str = Field(default="Main", max_length=64)


@app.post("/api/ticket")
def make_ticket(request: Request, authorization: str | None = Header(default=None)):
    require_admin(request, authorization)
    t = secrets.token_urlsafe(24)
    tickets[t] = time.time() + 30
    return {"ticket": t}


@app.post("/api/enroll")
def enroll(req: EnrollRequest, request: Request, authorization: str | None = Header(default=None)):
    """Creates a device identity; the raw token is returned ONCE and only its hash is stored."""
    require_admin(request, authorization)
    agent_id = secrets.token_hex(8)
    token = secrets.token_urlsafe(32)
    with closing(db()) as conn:
        conn.execute(
            "INSERT INTO agents (id, hostname, client, site, token, created_at) VALUES (?,?,?,?,?,?)",
            (agent_id, req.hostname.strip(), req.client.strip(), req.site.strip(), _hash_token(token), time.time()),
        )
        conn.commit()
    return {"agent_id": agent_id, "token": token}


@app.get("/api/agents")
def list_agents(request: Request, authorization: str | None = Header(default=None)):
    require_admin(request, authorization)
    with closing(db()) as conn:
        rows = conn.execute("SELECT id, hostname, client, site FROM agents ORDER BY hostname").fetchall()
    return [
        {"agent_id": r["id"], "hostname": r["hostname"], "client": r["client"], "site": r["site"],
         "online": r["id"] in agent_sockets, "live": live_state.get(r["id"])}
        for r in rows
    ]


@app.get("/api/audit")
def audit_log(request: Request, limit: int = 50, authorization: str | None = Header(default=None)):
    require_admin(request, authorization)
    limit = max(1, min(limit, 500))
    with closing(db()) as conn:
        rows = conn.execute(
            "SELECT ts, hostname, event, detail FROM audit ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
    return [dict(r) for r in rows]


@app.delete("/api/agents/{agent_id}")
async def remove_agent(agent_id: str, request: Request, authorization: str | None = Header(default=None)):
    """Drops the device identity + token. Session history (audit) is kept on purpose."""
    require_admin(request, authorization)
    with closing(db()) as conn:
        cur = conn.execute("DELETE FROM agents WHERE id = ?", (agent_id,))
        conn.commit()
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail="agent not found")
        conn.execute("VACUUM")
    _audit(agent_id, "removed", "device removed by admin")
    await _end_session(agent_id, "device removed")
    ws = agent_sockets.pop(agent_id, None)
    live_state.pop(agent_id, None)
    if ws is not None:
        try:
            await ws.close(code=4403)
        except Exception:
            pass
    await _broadcast({"type": "removed", "agent_id": agent_id})
    return {"removed": True, "agent_id": agent_id}


def _agent_id_for_token(token: str) -> str | None:
    if not token:
        return None
    with closing(db()) as conn:
        row = conn.execute("SELECT id FROM agents WHERE token = ?", (_hash_token(token),)).fetchone()
    return row["id"] if row else None

# ------------------------------------------------------------ agent websocket --

@app.websocket("/ws/agent")
async def ws_agent(ws: WebSocket):
    ip = _client_ip(ws)
    token = _bearer(ws.headers.get("authorization")) or ws.query_params.get("token", "")  # query = legacy v0.2 agents
    if _blocked(ip):
        await ws.accept()
        await ws.close(code=1013)  # try again later: agents retry, they do not exit
        return
    agent_id = _agent_id_for_token(token)
    if not agent_id:
        _record_fail(ip)
        await ws.close(code=4401)
        return

    await ws.accept()
    old = agent_sockets.get(agent_id)
    if old is not None:  # same device connected twice: newest wins
        await _end_session(agent_id, "agent reconnected")
        try:
            await old.close(code=4000)
        except Exception:
            pass
    agent_sockets[agent_id] = ws
    await _broadcast({"type": "online", "agent_id": agent_id})
    try:
        while True:
            msg = await ws.receive()
            if msg["type"] == "websocket.disconnect":
                break
            if msg.get("bytes") is not None:
                sess = sessions.get(agent_id)
                if sess and sess["approved"]:  # frames only flow inside an owner-approved session
                    await _safe_send(sess["viewer"], data=msg["bytes"])
                continue
            raw = msg.get("text")
            if raw is None or len(raw) > 4096:
                continue
            try:
                snap = json.loads(raw)
            except json.JSONDecodeError:
                continue
            if not isinstance(snap, dict):
                continue
            if snap.get("type") == "audit_event":
                q, now = _event_times[agent_id], time.time()
                while q and now - q[0] > 60:
                    q.popleft()
                ev, detail = snap.get("event"), snap.get("detail", "")
                if len(q) < 200 and ev in AGENT_EVENTS and isinstance(detail, str):
                    q.append(now)
                    _audit(agent_id, ev, detail)
                continue
            if "type" in snap:
                await _agent_session_msg(agent_id, snap)
                continue
            clean = {k: (v[:200] if isinstance(v, str) else v) for k, v in snap.items()
                     if k in TELE_KEYS and isinstance(v, (str, int, float))}
            clean["ts"] = time.time()
            live_state[agent_id] = clean
            await _broadcast({"type": "update", "agent_id": agent_id, "data": clean})
    except (WebSocketDisconnect, RuntimeError):
        pass
    finally:
        if agent_sockets.get(agent_id) is ws:
            agent_sockets.pop(agent_id, None)
            live_state.pop(agent_id, None)
            await _end_session(agent_id, "agent disconnected")
            await _broadcast({"type": "offline", "agent_id": agent_id})

# ------------------------------------------------------- remote session relay --

async def _safe_send(ws: WebSocket, text: str | None = None, data: bytes | None = None):
    try:
        if data is not None:
            await ws.send_bytes(data)
        elif text is not None:
            await ws.send_text(text)
    except Exception:
        pass


async def _agent_session_msg(agent_id: str, msg: dict):
    sess = sessions.get(agent_id)
    if not sess:
        return
    kind = msg.get("type")
    if kind == "approve" and not sess["approved"] and not sess["denied"]:
        sess["control"] = bool(msg.get("control")) and sess["want_control"]
        sess["approved"] = True
        sess["event"].set()
        _audit(agent_id, "allowed", "view + control" if sess["control"] else "view only")
        await _safe_send(sess["viewer"], text=json.dumps({"type": "approved", "control": sess["control"]}))
    elif kind == "deny" and not sess["approved"]:
        sess["denied"] = True
        sess["event"].set()
    elif kind == "end":
        await _end_session(agent_id, "ended by owner")


async def _end_session(agent_id: str, reason: str):
    sess = sessions.pop(agent_id, None)
    if not sess:
        return
    sess["event"].set()
    if sess["approved"]:
        _audit(agent_id, "ended", reason)
    await _safe_send(sess["viewer"], text=json.dumps({"type": "ended", "reason": reason}))
    try:
        await sess["viewer"].close()
    except Exception:
        pass
    agent_ws = agent_sockets.get(agent_id)
    if agent_ws is not None:
        await _safe_send(agent_ws, text=json.dumps({"type": "session_end"}))


@app.websocket("/ws/viewer")
async def ws_viewer(ws: WebSocket):
    """?ticket=<one-time ticket>&agent_id=<id>[&control=1]"""
    if not _use_ticket(ws.query_params.get("ticket", "")):
        await ws.close(code=4401)
        return
    agent_id = ws.query_params.get("agent_id", "")
    want_control = ws.query_params.get("control") == "1"
    if agent_id not in agent_sockets:
        await ws.close(code=4404)
        return
    if agent_id in sessions:
        await ws.close(code=4409)
        return

    sess = {"viewer": ws, "approved": False, "denied": False, "control": False,
            "want_control": want_control, "event": asyncio.Event()}
    sessions[agent_id] = sess
    await ws.accept()
    _audit(agent_id, "requested", "view + control" if want_control else "view only")
    try:
        await _safe_send(agent_sockets[agent_id], text=json.dumps({"type": "session_request", "control": want_control}))
        await _safe_send(ws, text=json.dumps({"type": "waiting_approval"}))
        try:
            await asyncio.wait_for(sess["event"].wait(), APPROVAL_TIMEOUT)
        except asyncio.TimeoutError:
            pass
        if not sess["approved"]:
            reason = "denied by owner" if sess["denied"] else "no approval in time"
            _audit(agent_id, "denied" if sess["denied"] else "timed out", reason)
            await _safe_send(ws, text=json.dumps({"type": "denied", "reason": reason}))
            return

        deadline = time.time() + MAX_SESSION_SECONDS
        while True:  # viewer -> agent: only whitelisted input events, only if control was granted
            remaining = deadline - time.time()
            if remaining <= 0:
                await _end_session(agent_id, "time limit reached")
                break
            try:
                msg = await asyncio.wait_for(ws.receive(), remaining)
            except asyncio.TimeoutError:
                continue
            if msg["type"] == "websocket.disconnect":
                break
            if sessions.get(agent_id) is not sess:
                break
            raw = msg.get("text")
            if raw is None or len(raw) > 512 or not sess["control"]:
                continue
            try:
                m = json.loads(raw)
            except ValueError:
                continue
            if not isinstance(m, dict) or m.get("t") not in INPUT_TYPES:
                continue
            agent_ws = agent_sockets.get(agent_id)
            if agent_ws is None:
                break
            await _safe_send(agent_ws, text=raw)
    except (WebSocketDisconnect, RuntimeError):
        pass
    finally:
        if sessions.get(agent_id) is sess:
            await _end_session(agent_id, "viewer disconnected")

# ---------------------------------------------------------- dashboard websocket --

@app.websocket("/ws/dashboard")
async def ws_dashboard(ws: WebSocket):
    if not _use_ticket(ws.query_params.get("ticket", "")):
        await ws.close(code=4401)
        return
    await ws.accept()
    dashboard_sockets.append(ws)
    try:
        while True:
            await ws.receive_text()
    except (WebSocketDisconnect, RuntimeError):
        pass
    finally:
        if ws in dashboard_sockets:
            dashboard_sockets.remove(ws)


async def _broadcast(payload: dict):
    text = json.dumps(payload)
    dead = []
    for d in list(dashboard_sockets):
        try:
            await d.send_text(text)
        except Exception:
            dead.append(d)
    for d in dead:
        if d in dashboard_sockets:
            dashboard_sockets.remove(d)


if __name__ == "__main__":
    import uvicorn

    print(f"[troyeye] v{VERSION} listening on {HOST}:{PORT}", flush=True)
    uvicorn.run(app, host=HOST, port=PORT, ws_ping_interval=20, ws_ping_timeout=20)
