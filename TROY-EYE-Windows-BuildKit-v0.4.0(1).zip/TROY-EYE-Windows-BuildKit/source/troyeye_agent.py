#!/usr/bin/env python3
"""
TROY EYE agent (v0.3.0) - runs on the PC that may be supported remotely.

It connects OUT to your server (no port-forwarding or VPN), reports basic stats, and when an
administrator asks to view the screen it shows an Allow / Deny prompt on this PC.
Nothing is captured or controllable until the PC owner clicks Allow. The owner chooses
"view only" or "view + control". While a session is live an always-on-top banner with a
"Stop sharing" button stays visible; closing the session or the agent ends it.
Every session is written to a local log (see below).

Run:   TROY-EYE-Agent.exe --config "C:\\Program Files\\TROY EYE\\agent.json"
Dev:   python troyeye_agent.py --server https://your-domain --token <device token>
Config file (JSON): {"server": "...", "token": "...", "fps": 5, "max_width": 1280, "quality": 55}
Log:   %LOCALAPPDATA%\\TROY EYE\\agent.log
If the server rejects the token (device removed/revoked) the agent exits and does not retry.
"""
import argparse
import asyncio
import base64
import concurrent.futures
import io
import json
import logging
import logging.handlers
import os
import platform
import queue
import re
import sys
import threading
import time
from urllib.parse import urlparse

import websockets

VERSION = "0.4.0"
SET = {"fps": 5, "max_width": 1280, "quality": 55}
CONFIG_KEYS = ("server", "token", "usb_audit", "watch_folders", "watch_interval", "fps", "max_width", "quality")
TOKEN_RE = re.compile(r"^[A-Za-z0-9_-]{20,}$")
MAX_WATCHED_FILES = 5000
MAX_WATCH_DEPTH = 3
PROMPT_SECONDS = 55  # server gives the owner 60s; answer slightly earlier
LOCAL_HOSTS = ("localhost", "127.0.0.1", "::1")

log = logging.getLogger("troyeye")


def app_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def setup_logging():
    for name in ("stdout", "stderr"):  # windowed builds have no console
        if getattr(sys, name) is None:
            setattr(sys, name, open(os.devnull, "w"))
    log.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    log.addHandler(sh)
    try:
        base = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), ".config")
        d = os.path.join(base, "TROY EYE")
        os.makedirs(d, exist_ok=True)
        fh = logging.handlers.RotatingFileHandler(os.path.join(d, "agent.log"), maxBytes=512_000,
                                                  backupCount=2, encoding="utf-8")
        fh.setFormatter(fmt)
        log.addHandler(fh)
    except Exception:
        pass


_instance_lock = None


def acquire_single_instance():
    """Only one agent per login session (installer launch + Startup entry must not collide)."""
    global _instance_lock
    if platform.system() == "Windows":
        import ctypes
        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        _instance_lock = k32.CreateMutexW(None, False, "TROYEYE_AGENT_SINGLETON")
        return ctypes.get_last_error() != 183  # ERROR_ALREADY_EXISTS
    try:
        import fcntl
        _instance_lock = open(os.path.join(os.environ.get("TMPDIR", "/tmp"), "troyeye-agent.lock"), "w")
        fcntl.flock(_instance_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        return False
    except Exception:
        pass
    return True

# ------------------------------------------------------------------ screen --

class RealScreen:
    """Primary monitor via mss. Must be used from ONE thread (see executor)."""

    def __init__(self):
        self._sct = None

    def grab(self):
        import mss
        from PIL import Image
        if self._sct is None:
            self._sct = mss.mss()
        shot = self._sct.grab(self._sct.monitors[1])
        img = Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")
        if img.width > SET["max_width"]:
            img = img.resize((SET["max_width"], int(img.height * SET["max_width"] / img.width)))
        buf = io.BytesIO()
        img.save(buf, "JPEG", quality=SET["quality"])
        return buf.getvalue()


class FakeScreen:
    """Test pattern, for protocol testing on machines with no display."""

    def grab(self):
        from PIL import Image, ImageDraw
        img = Image.new("RGB", (640, 360), (20, 30, 60))
        ImageDraw.Draw(img).text((20, 20), "TROY EYE test frame " + time.strftime("%H:%M:%S"), fill=(255, 255, 255))
        buf = io.BytesIO()
        img.save(buf, "JPEG", quality=70)
        return buf.getvalue()

# ------------------------------------------------------------------- input --

_KEYMAP = {
    "Enter": "enter", "Backspace": "backspace", "Tab": "tab", "Escape": "esc",
    "ArrowUp": "up", "ArrowDown": "down", "ArrowLeft": "left", "ArrowRight": "right",
    "Delete": "delete", "Home": "home", "End": "end", "PageUp": "pageup", "PageDown": "pagedown",
    "Shift": "shift", "Control": "ctrl", "Alt": "alt", "Meta": "win", " ": "space",
    "CapsLock": "capslock", "Insert": "insert",
}
_BUTTONS = {0: "left", 1: "middle", 2: "right"}


def _unit(v):
    return min(1.0, max(0.0, float(v)))


class RealInput:
    def __init__(self):
        import pyautogui
        pyautogui.FAILSAFE = False
        pyautogui.PAUSE = 0
        self.g = pyautogui
        self.keys = set()
        self.buttons = set()

    def apply(self, m):
        g = self.g
        w, h = g.size()
        t = m.get("t")
        if t == "move":
            g.moveTo(int(_unit(m["x"]) * (w - 1)), int(_unit(m["y"]) * (h - 1)))
        elif t in ("down", "up"):
            g.moveTo(int(_unit(m["x"]) * (w - 1)), int(_unit(m["y"]) * (h - 1)))
            btn = _BUTTONS.get(m.get("b", 0), "left")
            if t == "down":
                g.mouseDown(button=btn)
                self.buttons.add(btn)
            else:
                g.mouseUp(button=btn)
                self.buttons.discard(btn)
        elif t == "scroll":
            dy = float(m.get("dy", 0))
            if platform.system() == "Windows":  # pyautogui passes raw wheel units; one notch = 120
                amount = int(-dy / 100 * 120) or (-120 if dy > 0 else 120)
                amount = max(-1200, min(1200, amount))
            else:
                amount = int(-dy / 40) or (-1 if dy > 0 else 1)
            g.scroll(amount)
        elif t == "key":
            k = str(m.get("k", ""))
            name = _KEYMAP.get(k) or k.lower()
            if name in g.KEYBOARD_KEYS:
                if m.get("d"):
                    g.keyDown(name)
                    self.keys.add(name)
                else:
                    g.keyUp(name)
                    self.keys.discard(name)

    def release_all(self):
        """Never leave a key or mouse button stuck when a session ends."""
        for k in list(self.keys):
            try:
                self.g.keyUp(k)
            except Exception:
                pass
        for b in list(self.buttons):
            try:
                self.g.mouseUp(button=b)
            except Exception:
                pass
        self.keys.clear()
        self.buttons.clear()


class FakeInput:
    def __init__(self):
        self.log = []

    def apply(self, m):
        self.log.append(m)
        log.info("[fake input] %s", m)

    def release_all(self):
        pass

# ---------------------------------------------------------------------- UI --

class UI:
    """Allow/Deny prompt and always-on-top 'Stop sharing' banner (tkinter, in its own thread)."""

    def __init__(self, auto_approve=False):
        self.auto = auto_approve
        self.q = queue.Queue()
        self.tk_ok = False
        self._ready = threading.Event()
        if not auto_approve:
            threading.Thread(target=self._loop, daemon=True).start()
            self._ready.wait(5)

    def _loop(self):
        try:
            import tkinter as tk
            root = tk.Tk()
            root.withdraw()
        except Exception:
            self._ready.set()
            return
        self.tk_ok = True
        self._ready.set()
        banner = [None]

        def poll():
            try:
                while True:
                    cmd, arg = self.q.get_nowait()
                    if cmd == "ask":
                        self._dialog(root, *arg)
                    elif cmd == "banner":
                        banner[0] = self._banner(root, *arg)
                    elif cmd == "unbanner" and banner[0] is not None:
                        banner[0].destroy()
                        banner[0] = None
            except queue.Empty:
                pass
            root.after(100, poll)

        poll()
        root.mainloop()

    def _dialog(self, root, fut, want_control, host):
        import tkinter as tk
        win = tk.Toplevel(root)
        win.title("TROY EYE - remote access request")
        win.attributes("-topmost", True)
        what = "VIEW and CONTROL" if want_control else "VIEW"
        tk.Label(win, padx=24, pady=16, justify="left",
                 text=f"An administrator of {host} is asking to {what} this PC.\n\n"
                      "Nothing is shared unless you click Allow.").pack()
        done = [False]

        def finish(allowed, control=False):
            if not done[0]:
                done[0] = True
                fut.set_result((allowed, control))
                win.destroy()

        row = tk.Frame(win)
        row.pack(pady=(0, 14))
        if want_control:
            tk.Button(row, text="Allow view + control", command=lambda: finish(True, True)).pack(side="left", padx=6)
            tk.Button(row, text="Allow view only", command=lambda: finish(True, False)).pack(side="left", padx=6)
        else:
            tk.Button(row, text="Allow", width=10, command=lambda: finish(True, False)).pack(side="left", padx=6)
        tk.Button(row, text="Deny", width=10, command=lambda: finish(False)).pack(side="left", padx=6)
        win.protocol("WM_DELETE_WINDOW", lambda: finish(False))
        win.after(PROMPT_SECONDS * 1000, lambda: finish(False))
        win.lift()
        win.focus_force()
        win.bell()

    def _banner(self, root, stop_cb, control):
        import tkinter as tk
        win = tk.Toplevel(root)
        win.title("TROY EYE")
        win.attributes("-topmost", True)
        win.resizable(False, False)
        msg = "Your screen is being viewed and controlled" if control else "Your screen is being viewed"
        tk.Label(win, text=msg, fg="#b00020", padx=16, pady=8).pack()
        tk.Button(win, text="Stop sharing", command=stop_cb).pack(pady=(0, 10))
        win.protocol("WM_DELETE_WINDOW", stop_cb)
        win.update_idletasks()
        win.geometry("+%d+0" % max(0, (win.winfo_screenwidth() - win.winfo_reqwidth()) // 2))
        return win

    async def ask(self, want_control, host):
        """Returns (allowed, control_allowed). Fails closed when there is no way to ask."""
        if self.auto:
            log.warning("--auto-approve is on: approving without a prompt (TEST ONLY)")
            return True, want_control
        if self.tk_ok:
            from concurrent.futures import Future
            fut = Future()
            self.q.put(("ask", (fut, want_control, host)))
            return await asyncio.wrap_future(fut)
        if sys.stdin is not None and sys.stdin.isatty():
            loop = asyncio.get_running_loop()
            ans = await loop.run_in_executor(None, input, "Remote access request - allow? [y/N] ")
            ok = ans.strip().lower() in ("y", "yes")
            return ok, ok and want_control
        log.error("no way to show the Allow/Deny prompt - request denied")
        return False, False

    def show_banner(self, stop_cb, control):
        if self.tk_ok:
            self.q.put(("banner", (stop_cb, control)))

    def hide_banner(self):
        if self.tk_ok:
            self.q.put(("unbanner", None))


# ---------------------------------------------------------------- auditing --
# Both monitors are OFF unless enabled in agent.json (Settings window). Metadata only:
# drive letter/label, file paths + change type. Never file contents. Every event is also
# written to the local agent.log so the PC user can see exactly what was reported.

def usb_snapshot():
    """Removable drives currently present: {'E:': 'LABEL'}. Windows: DRIVE_REMOVABLE (flash drives, card readers)."""
    fake = os.environ.get("TROYEYE_FAKE_USB")
    if fake and not getattr(sys, "frozen", False):  # test hook, never active in release builds
        try:
            with open(fake, encoding="utf-8") as f:
                return {ln.split(" ", 1)[0]: (ln.split(" ", 1) + [""])[1].strip() for ln in f.read().splitlines() if ln.strip()}
        except OSError:
            return {}
    if platform.system() != "Windows":
        return {}
    import ctypes
    k32 = ctypes.windll.kernel32
    mask, out = k32.GetLogicalDrives(), {}
    for i in range(26):
        if mask & (1 << i):
            root = f"{chr(65 + i)}:\\"
            if k32.GetDriveTypeW(root) == 2:  # DRIVE_REMOVABLE
                buf = ctypes.create_unicode_buffer(261)
                ok = k32.GetVolumeInformationW(root, buf, 261, None, None, None, None, 0)
                out[root[:2]] = buf.value if ok else ""
    return out


def scan_folders(folders):
    """{path: (mtime_ns, size)} for up to MAX_WATCHED_FILES files, MAX_WATCH_DEPTH levels deep."""
    snap = {}
    for root in folders:
        base_depth = root.rstrip("\\/").count(os.sep)
        for dp, dn, fn in os.walk(root):
            if dp.count(os.sep) - base_depth >= MAX_WATCH_DEPTH:
                dn[:] = []
            for name in fn:
                path = os.path.join(dp, name)
                try:
                    st = os.stat(path)
                except OSError:
                    continue
                snap[path] = (st.st_mtime_ns, st.st_size)
                if len(snap) >= MAX_WATCHED_FILES:
                    return snap
    return snap


def diff_scans(old, new):
    ev = [("file created", p) for p in new if p not in old]
    ev += [("file deleted", p) for p in old if p not in new]
    ev += [("file modified", p) for p in new if p in old and new[p] != old[p]]
    return ev

# ---------------------------------------------------------------- settings --

def validate_settings(server, token, folders):
    p = urlparse((server or "").strip())
    if p.scheme not in ("http", "https") or not p.netloc:
        return "Server URL must look like https://your-domain"
    if p.scheme == "http" and p.hostname not in LOCAL_HOSTS:
        return "Use https:// (plain http is only allowed for localhost)."
    if token is not None and not TOKEN_RE.match(token):
        return "The device token looks wrong. Paste it exactly as shown in the dashboard."
    for f in folders:
        if not os.path.isabs(f):
            return "Watched folders must be full paths, e.g. C:\\Users\\Public\\Documents"
    return None


def write_config(path, cfg):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({k: cfg[k] for k in CONFIG_KEYS if k in cfg}, f, indent=2)
    os.replace(tmp, path)


def apply_config(path, b64):
    """Runs elevated (UAC) from the Settings window: validates and writes agent.json."""
    try:
        new = json.loads(base64.urlsafe_b64decode(b64.encode()).decode("utf-8"))
        cfg = load_config(path)
        cfg.update({k: new[k] for k in CONFIG_KEYS if k in new})
        err = validate_settings(cfg.get("server"), cfg.get("token"), cfg.get("watch_folders") or [])
        if err:
            log.error("settings rejected: %s", err)
            return 4
        write_config(path, cfg)
        log.info("settings saved (elevated)")
        return 0
    except Exception as e:
        log.error("apply-config failed: %s", e)
        return 4


def settings_gui(path):
    import tkinter as tk
    from tkinter import messagebox
    cfg = load_config(path)
    root = tk.Tk()
    root.title("TROY EYE Settings")
    root.resizable(False, False)
    pad = {"padx": 10, "pady": 4}
    tk.Label(root, text="Website URL (https://...)").grid(row=0, column=0, sticky="w", **pad)
    e_server = tk.Entry(root, width=48)
    e_server.insert(0, cfg.get("server", ""))
    e_server.grid(row=0, column=1, **pad)
    tk.Label(root, text="Device token").grid(row=1, column=0, sticky="w", **pad)
    e_token = tk.Entry(root, width=48, show="*")
    e_token.grid(row=1, column=1, **pad)
    tk.Label(root, fg="#666", text="Leave blank to keep the current token." if cfg.get("token") else "Required.").grid(row=2, column=1, sticky="w", padx=10)
    usb = tk.BooleanVar(value=bool(cfg.get("usb_audit")))
    tk.Checkbutton(root, variable=usb, text="Report when a USB drive is inserted or removed (drive letter + label only)").grid(row=3, column=0, columnspan=2, sticky="w", **pad)
    tk.Label(root, text="Report file changes in these folders\n(one full path per line; names and change type only,\nup to 5,000 files, 3 levels deep; empty = off)", justify="left").grid(row=4, column=0, sticky="nw", **pad)
    t_dirs = tk.Text(root, width=48, height=5)
    t_dirs.insert("1.0", "\n".join(cfg.get("watch_folders") or []))
    t_dirs.grid(row=4, column=1, **pad)
    tk.Label(root, fg="#666", justify="left",
             text="Everything reported is also written to %LOCALAPPDATA%\\TROY EYE\\agent.log.\nChanging settings needs administrator approval (Windows will ask).").grid(row=5, column=0, columnspan=2, sticky="w", **pad)
    status = tk.Label(root, text="")
    status.grid(row=6, column=0, columnspan=2, sticky="w", **pad)

    def save():
        server = e_server.get().strip()
        token = e_token.get().strip() or None
        folders = [ln.strip() for ln in t_dirs.get("1.0", "end").splitlines() if ln.strip()]
        err = validate_settings(server, token if token else cfg.get("token") or "", folders) if (token or cfg.get("token")) else "Enter the device token."
        if not err:
            bad = [f for f in folders if not os.path.isdir(f)]
            if bad:
                err = "Folder not found: " + bad[0]
        if err:
            messagebox.showerror("TROY EYE", err)
            return
        new = dict(cfg)
        new.update(server=server, usb_audit=usb.get(), watch_folders=folders)
        if token:
            new["token"] = token
        try:
            write_config(path, new)
            messagebox.showinfo("TROY EYE", "Saved. The running agent reloads automatically.")
            root.destroy()
            return
        except PermissionError:
            pass
        if platform.system() != "Windows":
            messagebox.showerror("TROY EYE", "No permission to write " + path)
            return
        import ctypes
        payload = base64.urlsafe_b64encode(json.dumps({k: new[k] for k in CONFIG_KEYS if k in new}).encode()).decode()
        if getattr(sys, "frozen", False):
            exe, params = sys.executable, f'--apply-config {payload} --config "{path}"'
        else:
            exe, params = sys.executable, f'"{os.path.abspath(__file__)}" --apply-config {payload} --config "{path}"'
        if ctypes.windll.shell32.ShellExecuteW(None, "runas", exe, params, None, 0) <= 32:
            messagebox.showerror("TROY EYE", "Administrator approval was cancelled. Nothing was changed.")
            return
        status.config(text="Waiting for administrator approval...")
        deadline = time.time() + 90

        def wait():
            cur = load_config(path)
            if all(cur.get(k) == new.get(k) for k in ("server", "token", "usb_audit", "watch_folders")):
                messagebox.showinfo("TROY EYE", "Saved. The running agent reloads automatically.")
                root.destroy()
            elif time.time() > deadline:
                status.config(text="")
                messagebox.showerror("TROY EYE", "Settings were not applied.")
            else:
                root.after(500, wait)
        wait()

    row = tk.Frame(root)
    row.grid(row=7, column=0, columnspan=2, pady=10)
    tk.Button(row, text="Save", width=10, command=save).pack(side="left", padx=6)
    tk.Button(row, text="Cancel", width=10, command=root.destroy).pack(side="left", padx=6)
    root.mainloop()

# ------------------------------------------------------------------- agent --

def telemetry():
    snap = {"os": platform.platform(), "host": platform.node()}
    try:
        import psutil
        snap.update(cpu=psutil.cpu_percent(), ram=psutil.virtual_memory().percent,
                    disk=psutil.disk_usage(os.path.abspath(os.sep)).percent,
                    uptime_s=int(time.time() - psutil.boot_time()))
    except Exception:
        pass
    return snap


def close_code(exc):
    return getattr(getattr(exc, "rcvd", None), "code", None)


def http_status(exc):
    resp = getattr(exc, "response", None)
    if resp is not None:
        return getattr(resp, "status_code", None)
    return getattr(exc, "status_code", None)


def ws_connect(url, token):
    major = int(str(websockets.__version__).split(".")[0])
    key = "additional_headers" if major >= 14 else "extra_headers"
    return websockets.connect(url, max_size=None, ping_interval=20, ping_timeout=20, open_timeout=20,
                              **{key: {"Authorization": "Bearer " + token}})


async def serve(url, token, host, screen_factory, input_factory, ui, ctx, opts):
    loop = asyncio.get_running_loop()
    executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)  # capture stays on one thread
    screen = screen_factory()
    inp = [None]
    state = {"capture": None, "active": False, "asking": False, "control": False}

    async with ws_connect(url, token) as ws:
        ctx["connected"] = True
        log.info("connected to %s", host)

        async def send_json(obj):
            await ws.send(json.dumps(obj))

        async def stop_session(notify=True):
            was_active = state["active"]
            state["active"] = False
            state["control"] = False
            task, state["capture"] = state["capture"], None
            if task and task is not asyncio.current_task():
                task.cancel()
            if inp[0] is not None:
                try:
                    inp[0].release_all()
                except Exception:
                    pass
            ui.hide_banner()
            if was_active:
                log.info("session ended")
            if notify:
                try:
                    await send_json({"type": "end"})
                except Exception:
                    pass

        async def capture_loop():
            interval = 1.0 / SET["fps"]
            fails = 0
            while True:
                t0 = time.time()
                try:
                    frame = await loop.run_in_executor(executor, screen.grab)
                    fails = 0
                except Exception as e:  # e.g. secure desktop / UAC prompt / display change
                    fails += 1
                    log.warning("screen capture failed: %s", e)
                    if fails >= 20:
                        log.error("capture keeps failing - ending session")
                        await stop_session()
                        return
                    await asyncio.sleep(0.5)
                    continue
                try:
                    await ws.send(frame)
                except Exception:
                    return
                await asyncio.sleep(max(0, interval - (time.time() - t0)))

        async def handle_request(want_control):
            if state["active"] or state["asking"]:
                await send_json({"type": "deny"})
                return
            state["asking"] = True
            log.info("remote %s request from %s", "view+control" if want_control else "view", host)
            try:
                allowed, control = await ui.ask(want_control, host)
            finally:
                state["asking"] = False
            if not allowed:
                log.info("request denied by owner")
                await send_json({"type": "deny"})
                return
            control = bool(control and want_control)
            state["active"], state["control"] = True, control
            log.info("session started (%s)", "view + control" if control else "view only")
            await send_json({"type": "approve", "control": control})
            ui.show_banner(lambda: asyncio.run_coroutine_threadsafe(stop_session(), loop), control)
            state["capture"] = asyncio.create_task(capture_loop())

        async def telemetry_loop():
            while True:
                await send_json(telemetry())
                await asyncio.sleep(3)

        async def emit(event, detail):
            log.info("audit: %s %s", event, detail)
            try:
                await send_json({"type": "audit_event", "event": event, "detail": detail[:200]})
            except Exception:
                pass

        async def usb_loop():
            prev = await loop.run_in_executor(None, usb_snapshot)
            while True:
                await asyncio.sleep(3)
                cur = await loop.run_in_executor(None, usb_snapshot)
                for d, lbl in cur.items():
                    if d not in prev:
                        await emit("usb inserted", f"{d} {lbl}".strip())
                for d, lbl in prev.items():
                    if d not in cur:
                        await emit("usb removed", f"{d} {lbl}".strip())
                prev = cur

        async def files_loop():
            folders = opts["folders"]
            prev = await loop.run_in_executor(None, scan_folders, folders)
            if len(prev) >= MAX_WATCHED_FILES:
                log.warning("watched folders exceed %d files; only the first %d are monitored", MAX_WATCHED_FILES, MAX_WATCHED_FILES)
            while True:
                await asyncio.sleep(opts["interval"])
                cur = await loop.run_in_executor(None, scan_folders, folders)
                ev = diff_scans(prev, cur)
                for name, path in ev[:50]:
                    await emit(name, path)
                if len(ev) > 50:
                    await emit("file activity", f"{len(ev) - 50} more changes not listed")
                prev = cur

        tele = asyncio.create_task(telemetry_loop())
        monitors = []
        if opts["usb"]:
            monitors.append(asyncio.create_task(usb_loop()))
            log.info("USB auditing is ON")
        if opts["folders"]:
            monitors.append(asyncio.create_task(files_loop()))
            log.info("folder auditing is ON for %d folder(s)", len(opts["folders"]))
        try:
            async for msg in ws:
                if isinstance(msg, bytes):
                    continue
                try:
                    m = json.loads(msg)
                except ValueError:
                    continue
                if not isinstance(m, dict):
                    continue
                kind = m.get("type")
                if kind == "session_request":
                    asyncio.create_task(handle_request(bool(m.get("control"))))
                elif kind == "session_end":
                    await stop_session(notify=False)
                elif "t" in m and state["active"] and state["control"]:  # input only if owner allowed control
                    if inp[0] is None:
                        inp[0] = input_factory()
                    try:
                        inp[0].apply(m)
                    except Exception as e:
                        log.warning("input error: %s", e)
        finally:
            tele.cancel()
            for t in monitors:
                t.cancel()
            await stop_session(notify=False)
            executor.shutdown(wait=False)


def effective_settings(args):
    """CLI flags override agent.json; everything else comes from the file (re-read on change)."""
    cfg = load_config(args.config)
    for key in SET:
        if isinstance(cfg.get(key), int) and cfg[key] > 0:
            SET[key] = cfg[key]
    SET["fps"] = min(SET["fps"], 15)
    SET["quality"] = min(SET["quality"], 95)
    folders = [f for f in (cfg.get("watch_folders") or []) if isinstance(f, str) and os.path.isabs(f)]
    interval = cfg.get("watch_interval")
    return {"server": args.server or cfg.get("server"), "token": args.token or cfg.get("token"),
            "usb": cfg.get("usb_audit") is True, "folders": folders,
            "interval": max(2, interval) if isinstance(interval, int) else 10}


def config_stamp(path):
    try:
        st = os.stat(path)
        return (st.st_mtime_ns, st.st_size)
    except OSError:
        return None


async def main_async(args):
    ui = UI(auto_approve=args.auto_approve)
    screen_factory = FakeScreen if args.fake else RealScreen
    input_factory = FakeInput if args.fake else RealInput
    backoff = 1
    while True:
        opts = effective_settings(args)
        stamp = config_stamp(args.config)
        if not opts["server"] or not opts["token"]:
            log.error("no server/token configured - open TROY EYE Settings")
            await asyncio.sleep(5)
            if config_stamp(args.config) == stamp:
                continue
            continue
        p = urlparse(opts["server"].strip())
        if p.scheme not in ("http", "https") or not p.netloc:
            log.error("server URL must look like https://your-domain")
            return 3
        if p.scheme == "http" and p.hostname not in LOCAL_HOSTS:
            log.error("refusing plain http to a remote server - the token would travel unencrypted. Use https.")
            return 3
        url = f"{'wss' if p.scheme == 'https' else 'ws'}://{p.netloc}{p.path.rstrip('/')}/ws/agent"
        ctx = {"connected": False}
        task = asyncio.create_task(serve(url, opts["token"], p.netloc, screen_factory, input_factory, ui, ctx, opts))
        changed = False
        while not task.done():
            await asyncio.wait({task}, timeout=3)
            if not task.done() and config_stamp(args.config) != stamp:
                log.info("settings changed - reloading")
                task.cancel()
                changed = True
        try:
            await task
        except asyncio.CancelledError:
            pass
        except websockets.ConnectionClosed as e:
            if close_code(e) in (4401, 4403):
                log.error("this device was removed/revoked on the server - exiting.")
                return 2
            log.info("disconnected: %s", e)
        except Exception as e:
            if http_status(e) in (401, 403):
                log.error("server rejected this token (device removed/revoked) - exiting.")
                return 2
            log.warning("connection failed: %s", e)
        if changed:
            backoff = 1
            continue
        if ctx["connected"]:
            backoff = 1
        await asyncio.sleep(backoff)
        backoff = min(backoff * 2, 30)


def load_config(path):
    try:
        with open(path, encoding="utf-8-sig") as f:
            cfg = json.load(f)
        return cfg if isinstance(cfg, dict) else {}
    except FileNotFoundError:
        return {}
    except Exception as e:
        log.error("cannot read config %s: %s", path, e)
        return {}


def main():
    setup_logging()
    if platform.system() == "Windows":
        try:  # make screen + mouse coordinates agree on high-DPI displays
            import ctypes
            try:
                ctypes.windll.shcore.SetProcessDpiAwareness(2)
            except Exception:
                ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass
    ap = argparse.ArgumentParser(description="TROY EYE agent")
    ap.add_argument("--server")
    ap.add_argument("--token")
    ap.add_argument("--config", default=os.path.join(app_dir(), "agent.json"))
    ap.add_argument("--fake", action="store_true", help="test pattern + logged input (no display needed)")
    ap.add_argument("--auto-approve", action="store_true", help="TEST ONLY: skip the Allow prompt")
    ap.add_argument("--settings", action="store_true", help="open the settings window")
    ap.add_argument("--apply-config", help=argparse.SUPPRESS)
    ap.add_argument("--version", action="version", version="TROY EYE agent " + VERSION)
    args = ap.parse_args()
    if getattr(sys, "frozen", False):  # release builds never carry the test switches
        args.auto_approve = args.fake = False
    if args.apply_config:
        sys.exit(apply_config(args.config, args.apply_config))
    if args.settings:
        settings_gui(args.config)
        return
    cfg = load_config(args.config)
    if (not args.server or not args.token) and not (cfg.get("server") and cfg.get("token")):
        log.error("need --server and --token (or agent.json at %s)", args.config)
        sys.exit(2)
    if not acquire_single_instance():
        log.info("TROY EYE agent is already running - exiting")
        sys.exit(0)
    log.info("TROY EYE agent %s starting", VERSION)
    try:
        sys.exit(asyncio.run(main_async(args)))
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
